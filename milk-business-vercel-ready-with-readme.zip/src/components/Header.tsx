import { Milk } from "lucide-react";

export function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Milk className="w-8 h-8 text-green-600" />
          <div>
            <h1 className="text-green-700">Gopala Dairy</h1>
            <p className="text-xs text-gray-600">Farm to Cup - Drink it Up</p>
          </div>
        </div>
        <nav className="hidden md:flex gap-6">
          <a href="#home" className="text-gray-700 hover:text-green-600 transition">Home</a>
          <a href="#about" className="text-gray-700 hover:text-green-600 transition">About</a>
          <a href="#products" className="text-gray-700 hover:text-green-600 transition">Products</a>
          <a href="#subscription" className="text-gray-700 hover:text-green-600 transition">Subscription</a>
        </nav>
      </div>
    </header>
  );
}
