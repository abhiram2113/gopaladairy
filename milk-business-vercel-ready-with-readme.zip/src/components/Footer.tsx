import { Milk, Phone, MapPin, MessageCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-green-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Milk className="w-8 h-8" />
              <div>
                <h3 className="text-white">Gopala Dairy</h3>
                <p className="text-sm text-green-200">Farm to Cup - Drink it Up</p>
              </div>
            </div>
            <p className="text-green-100">
              Delivering 100% pure and natural milk directly from our farms to your home.
            </p>
          </div>
          <div>
            <h4 className="text-white mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span className="text-green-100">7661036584</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span className="text-green-100">Siddipet</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-green-700 mt-8 pt-8 text-center text-green-200">
          <p>&copy; 2025 Gopala Dairy. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
