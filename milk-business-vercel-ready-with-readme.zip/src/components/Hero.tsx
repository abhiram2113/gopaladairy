import logo from 'figma:asset/1e6866b59ef85621b095911fab8b60ceb9098a1a.png';

export function Hero() {
  return (
    <section id="home" className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <img
              src={logo}
              alt="Gopala Dairy Logo"
              className="w-64 h-64 object-contain"
            />
          </div>
          <h1 className="text-green-700 mb-4">Gopala Dairy</h1>
          <p className="text-2xl text-gray-700 mb-8">Farm to Cup - Drink it Up</p>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            100% pure and natural milk directly from farms
          </p>
        </div>
      </div>
    </section>
  );
}
