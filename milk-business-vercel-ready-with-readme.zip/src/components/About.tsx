import { Leaf, Heart, Truck } from "lucide-react";

export function About() {
  const features = [
    {
      icon: Leaf,
      title: "100% Natural",
      description: "No preservatives, no additives - just pure milk from our farms"
    },
    {
      icon: Heart,
      title: "Farm Fresh",
      description: "Delivered directly from our farms to maintain maximum freshness"
    },
    {
      icon: Truck,
      title: "Daily Delivery",
      description: "Fresh products delivered to your doorstep every single day"
    }
  ];

  return (
    <section id="about" className="py-20 bg-green-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-green-700 mb-4">Why Choose Gopala Dairy?</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Our mission is to provide you with the purest, most natural dairy products. 
            We believe in direct farm-to-cup delivery, ensuring you get the freshest milk and curd every day.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 mt-12">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-md text-center">
              <feature.icon className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-green-700 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
