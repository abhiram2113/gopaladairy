import { ImageWithFallback } from './figma/ImageWithFallback';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import milkBottlesImage from 'figma:asset/1b4ec35f1f9740071ab6233e299d1b3509f98c85.png';
import curdPotImage from 'figma:asset/56434873c2f03d236564f56484a98dda289a0332.png';

export function Products() {
  const products = [
    {
      name: "Fresh Milk",
      image: milkBottlesImage,
      description: "Fresh, pure milk from our farm",
      prices: [
        { size: "Half Liter", price: 45 },
        { size: "1 Liter", price: 90 }
      ]
    },
    {
      name: "Homemade Curd",
      image: curdPotImage,
      description: "Creamy, delicious curd made from our fresh milk",
      prices: [
        { size: "Half KG", price: 60 },
        { size: "1 KG", price: 120 }
      ]
    }
  ];

  return (
    <section id="products" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-green-700 mb-4">Our Products</h2>
          <p className="text-xl text-gray-700">
            Farm-fresh dairy products delivered to your home
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {products.map((product, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="relative h-64 w-full bg-gray-100">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover block"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-green-700">{product.name}</CardTitle>
                <CardDescription>{product.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {product.prices.map((priceOption, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                      <span className="text-gray-700">{priceOption.size}</span>
                      <Badge className="bg-green-600">₹{priceOption.price}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
