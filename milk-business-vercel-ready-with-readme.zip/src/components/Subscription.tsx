import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Gift, Calendar, Sparkles, MessageCircle } from 'lucide-react';

export function Subscription() {
  const offers = [
    {
      icon: Gift,
      title: "7-Day Offer",
      description: "Order for 6 consecutive days and get the 7th day FREE!",
      highlight: "Applicable for both milk and curd",
      color: "bg-blue-50 border-blue-200"
    },
    {
      icon: Calendar,
      title: "Monthly Subscription",
      description: "Subscribe for 1 month and enjoy a flat 10% discount on all products",
      highlight: "Save more with regular delivery",
      color: "bg-purple-50 border-purple-200"
    }
  ];

  return (
    <section id="subscription" className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-green-600" />
            <h2 className="text-green-700">Special Offers</h2>
          </div>
          <p className="text-xl text-gray-700">
            Save more with our subscription plans
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {offers.map((offer, index) => (
            <Card key={index} className={`border-2 ${offer.color}`}>
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <offer.icon className="w-10 h-10 text-green-600" />
                  <CardTitle className="text-green-700">{offer.title}</CardTitle>
                </div>
                <CardDescription className="text-lg">{offer.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-white p-4 rounded-lg border-2 border-green-200">
                  <p className="text-green-700 text-center">{offer.highlight}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-6">
            Ready to enjoy fresh, pure dairy products every day?
          </p>
          <a 
            href="https://wa.me/message/X7I6PCELZ5GTM1" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-green-600 hover:bg-green-700 text-white py-4 px-8 rounded-lg inline-flex items-center gap-2 transition"
          >
            <MessageCircle className="w-6 h-6" />
            <span className="text-xl">Contact us to start your subscription today!</span>
          </a>
        </div>
      </div>
    </section>
  );
}
