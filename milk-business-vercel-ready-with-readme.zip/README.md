
  # Milk Selling Business Plan

  This is a code bundle for Milk Selling Business Plan. The original project is available at https://www.figma.com/design/EA56nU00Jr4JcJiHpqOF99/Milk-Selling-Business-Plan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  