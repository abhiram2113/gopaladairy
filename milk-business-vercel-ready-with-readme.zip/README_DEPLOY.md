# 🚀 Deploying to Vercel

This project is ready for deployment on **Vercel**.

---

## 🧩 Requirements
- Node.js (v18+ recommended)
- Vercel CLI (`npm install -g vercel`)

---

## ⚙️ Deployment Steps

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Build the project**
   ```bash
   npm run build
   ```

3. **Deploy to Vercel**
   ```bash
   vercel
   ```

   Follow the CLI prompts (login if needed and choose a project name).

4. **Deploy to Production**
   ```bash
   vercel deploy --prod
   ```

---

## 🌐 Output

After successful deployment, you'll get:
- A preview URL (e.g., `https://your-project.vercel.app`)
- A production URL after the `--prod` step

---

**Included files:**
- `vercel.json` → Configuration for Vercel static build
- `index.html` → Vite build entry
- `src/` → React + TypeScript components

Enjoy your deployment! 🎉
